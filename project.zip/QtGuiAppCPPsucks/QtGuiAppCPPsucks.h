#pragma once

#include <QtWidgets/QMainWindow>
#include "ui_QtGuiAppCPPsucks.h"


#include<opencv2/opencv.hpp>
#include"QFileDialog"
#include "QMessageBox"
//#include<math.h>
#include<iostream>
using namespace cv;
using namespace std;

Mat QImage2Mat(QImage*  InputImage);
void Graying(Mat source);
void Resize(Mat source, int width, int height);
void resizescale(Mat source, double scale);
void CharConvert(Mat source);
void Denoise(Mat source);
void GuassBlur(Mat source);// also can do Denoise
void laplaceSharpenFliter2d(Mat source);
void ContourRec(Mat source);


void videoCharConv();
void videoContourRec(VideoCapture camera);//����ʶ��

class QtGuiAppCPPsucks : public QMainWindow
{
	
	Q_OBJECT
public:	QString OriginImagePath;
public : int videostop = 0;
public: int PlayStop = 0;
public:QString OriginVideoPath;
 	QtGuiAppCPPsucks(QWidget *parent = Q_NULLPTR);

public :
	Ui::QtGuiAppCPPsucksClass ui;

public slots: void PicOpenPicButtonClicked();

public slots: void GrayingButtonClicked();
public slots: void ResizeButtonClicked();
public slots: void ResizeScaleButtonClicked();
public slots: void CharConvertButtonClicked();
public slots: void DenoiseButtonClicked();
public slots: void GuassBlurButtonClicked();
public slots: void SharpenButtonClicked();
public slots: void ContourRecButtonClicked();
public slots: void CameraOpenClicked();
public slots: void CameraCloseClicked();
public  slots: void  OpenVideo();
public slots: void VideoGraying();
public slots: void CloseVideo();
};
