#include "QtGuiAppCPPsucks.h"
#include <QtWidgets/QApplication>

int main(int argc, char *argv[])
{
	QApplication a(argc, argv);
	QtGuiAppCPPsucks w;
	w.show();
	return a.exec();
}
