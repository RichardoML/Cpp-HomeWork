/********************************************************************************
** Form generated from reading UI file 'QtGuiAppCPPsucks.ui'
**
** Created by: Qt User Interface Compiler version 5.9.9
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_QTGUIAPPCPPSUCKS_H
#define UI_QTGUIAPPCPPSUCKS_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_QtGuiAppCPPsucksClass
{
public:
    QWidget *centralWidget;
    QTabWidget *tabWidget;
    QWidget *TabPicture;
    QLabel *OriginImage;
    QPushButton *pushButton;
    QWidget *verticalLayoutWidget;
    QVBoxLayout *verticalLayout;
    QPushButton *pushButton_2;
    QPushButton *pushButton_3;
    QPushButton *pushButton_4;
    QPushButton *pushButton_7;
    QPushButton *pushButton_8;
    QPushButton *pushButton_9;
    QLabel *label;
    QLabel *label_2;
    QWidget *TabVideo;
    QLabel *VideoOrigin;
    QPushButton *VideoOpenVideo;
    QPushButton *VideoGraying;
    QPushButton *pushButton_5;
    QLabel *label_6;
    QLabel *label_7;
    QLabel *label_8;
    QWidget *TabCamera;
    QWidget *layoutWidget;
    QVBoxLayout *verticalLayout_2;
    QPushButton *pushButton_10;
    QPushButton *pushButton_11;
    QLabel *label_3;
    QLabel *label_4;
    QLabel *label_5;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *QtGuiAppCPPsucksClass)
    {
        if (QtGuiAppCPPsucksClass->objectName().isEmpty())
            QtGuiAppCPPsucksClass->setObjectName(QStringLiteral("QtGuiAppCPPsucksClass"));
        QtGuiAppCPPsucksClass->resize(1105, 725);
        centralWidget = new QWidget(QtGuiAppCPPsucksClass);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        tabWidget = new QTabWidget(centralWidget);
        tabWidget->setObjectName(QStringLiteral("tabWidget"));
        tabWidget->setGeometry(QRect(0, 0, 1101, 721));
        TabPicture = new QWidget();
        TabPicture->setObjectName(QStringLiteral("TabPicture"));
        OriginImage = new QLabel(TabPicture);
        OriginImage->setObjectName(QStringLiteral("OriginImage"));
        OriginImage->setGeometry(QRect(0, 0, 701, 551));
        OriginImage->setFrameShape(QFrame::WinPanel);
        OriginImage->setAlignment(Qt::AlignCenter);
        pushButton = new QPushButton(TabPicture);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(270, 580, 93, 28));
        verticalLayoutWidget = new QWidget(TabPicture);
        verticalLayoutWidget->setObjectName(QStringLiteral("verticalLayoutWidget"));
        verticalLayoutWidget->setGeometry(QRect(700, 100, 101, 321));
        verticalLayout = new QVBoxLayout(verticalLayoutWidget);
        verticalLayout->setSpacing(6);
        verticalLayout->setContentsMargins(11, 11, 11, 11);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        pushButton_2 = new QPushButton(verticalLayoutWidget);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));

        verticalLayout->addWidget(pushButton_2);

        pushButton_3 = new QPushButton(verticalLayoutWidget);
        pushButton_3->setObjectName(QStringLiteral("pushButton_3"));

        verticalLayout->addWidget(pushButton_3);

        pushButton_4 = new QPushButton(verticalLayoutWidget);
        pushButton_4->setObjectName(QStringLiteral("pushButton_4"));

        verticalLayout->addWidget(pushButton_4);

        pushButton_7 = new QPushButton(verticalLayoutWidget);
        pushButton_7->setObjectName(QStringLiteral("pushButton_7"));

        verticalLayout->addWidget(pushButton_7);

        pushButton_8 = new QPushButton(verticalLayoutWidget);
        pushButton_8->setObjectName(QStringLiteral("pushButton_8"));

        verticalLayout->addWidget(pushButton_8);

        pushButton_9 = new QPushButton(verticalLayoutWidget);
        pushButton_9->setObjectName(QStringLiteral("pushButton_9"));

        verticalLayout->addWidget(pushButton_9);

        label = new QLabel(TabPicture);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(810, 170, 171, 21));
        label_2 = new QLabel(TabPicture);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(810, 230, 131, 16));
        tabWidget->addTab(TabPicture, QString());
        TabVideo = new QWidget();
        TabVideo->setObjectName(QStringLiteral("TabVideo"));
        VideoOrigin = new QLabel(TabVideo);
        VideoOrigin->setObjectName(QStringLiteral("VideoOrigin"));
        VideoOrigin->setGeometry(QRect(0, 0, 711, 521));
        VideoOrigin->setFrameShape(QFrame::WinPanel);
        VideoOrigin->setAlignment(Qt::AlignCenter);
        VideoOpenVideo = new QPushButton(TabVideo);
        VideoOpenVideo->setObjectName(QStringLiteral("VideoOpenVideo"));
        VideoOpenVideo->setGeometry(QRect(310, 570, 93, 28));
        VideoGraying = new QPushButton(TabVideo);
        VideoGraying->setObjectName(QStringLiteral("VideoGraying"));
        VideoGraying->setGeometry(QRect(810, 170, 93, 28));
        pushButton_5 = new QPushButton(TabVideo);
        pushButton_5->setObjectName(QStringLiteral("pushButton_5"));
        pushButton_5->setGeometry(QRect(460, 570, 93, 28));
        label_6 = new QLabel(TabVideo);
        label_6->setObjectName(QStringLiteral("label_6"));
        label_6->setGeometry(QRect(580, 570, 351, 31));
        label_7 = new QLabel(TabVideo);
        label_7->setObjectName(QStringLiteral("label_7"));
        label_7->setGeometry(QRect(580, 600, 471, 31));
        label_8 = new QLabel(TabVideo);
        label_8->setObjectName(QStringLiteral("label_8"));
        label_8->setGeometry(QRect(580, 630, 351, 31));
        tabWidget->addTab(TabVideo, QString());
        TabCamera = new QWidget();
        TabCamera->setObjectName(QStringLiteral("TabCamera"));
        layoutWidget = new QWidget(TabCamera);
        layoutWidget->setObjectName(QStringLiteral("layoutWidget"));
        layoutWidget->setGeometry(QRect(10, 20, 95, 161));
        verticalLayout_2 = new QVBoxLayout(layoutWidget);
        verticalLayout_2->setSpacing(6);
        verticalLayout_2->setContentsMargins(11, 11, 11, 11);
        verticalLayout_2->setObjectName(QStringLiteral("verticalLayout_2"));
        verticalLayout_2->setContentsMargins(0, 0, 0, 0);
        pushButton_10 = new QPushButton(layoutWidget);
        pushButton_10->setObjectName(QStringLiteral("pushButton_10"));

        verticalLayout_2->addWidget(pushButton_10);

        pushButton_11 = new QPushButton(layoutWidget);
        pushButton_11->setObjectName(QStringLiteral("pushButton_11"));

        verticalLayout_2->addWidget(pushButton_11);

        label_3 = new QLabel(TabCamera);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setGeometry(QRect(150, 50, 611, 16));
        label_4 = new QLabel(TabCamera);
        label_4->setObjectName(QStringLiteral("label_4"));
        label_4->setGeometry(QRect(150, 70, 601, 21));
        label_5 = new QLabel(TabCamera);
        label_5->setObjectName(QStringLiteral("label_5"));
        label_5->setGeometry(QRect(150, 120, 601, 21));
        tabWidget->addTab(TabCamera, QString());
        QtGuiAppCPPsucksClass->setCentralWidget(centralWidget);
        statusBar = new QStatusBar(QtGuiAppCPPsucksClass);
        statusBar->setObjectName(QStringLiteral("statusBar"));
        QtGuiAppCPPsucksClass->setStatusBar(statusBar);

        retranslateUi(QtGuiAppCPPsucksClass);
        QObject::connect(pushButton, SIGNAL(clicked()), QtGuiAppCPPsucksClass, SLOT(PicOpenPicButtonClicked()));
        QObject::connect(pushButton_2, SIGNAL(clicked()), QtGuiAppCPPsucksClass, SLOT(GrayingButtonClicked()));
        QObject::connect(pushButton_3, SIGNAL(clicked()), QtGuiAppCPPsucksClass, SLOT(ResizeButtonClicked()));
        QObject::connect(pushButton_4, SIGNAL(clicked()), QtGuiAppCPPsucksClass, SLOT(ResizeScaleButtonClicked()));
        QObject::connect(pushButton_7, SIGNAL(clicked()), QtGuiAppCPPsucksClass, SLOT(GuassBlurButtonClicked()));
        QObject::connect(pushButton_8, SIGNAL(clicked()), QtGuiAppCPPsucksClass, SLOT(SharpenButtonClicked()));
        QObject::connect(pushButton_9, SIGNAL(clicked()), QtGuiAppCPPsucksClass, SLOT(ContourRecButtonClicked()));
        QObject::connect(pushButton_10, SIGNAL(clicked()), QtGuiAppCPPsucksClass, SLOT(CameraOpenClicked()));
        QObject::connect(pushButton_11, SIGNAL(clicked()), QtGuiAppCPPsucksClass, SLOT(CameraCloseClicked()));
        QObject::connect(VideoOpenVideo, SIGNAL(clicked()), QtGuiAppCPPsucksClass, SLOT(OpenVideo()));
        QObject::connect(VideoGraying, SIGNAL(clicked()), QtGuiAppCPPsucksClass, SLOT(VideoGraying()));
        QObject::connect(pushButton_5, SIGNAL(clicked()), QtGuiAppCPPsucksClass, SLOT(CloseVideo()));

        tabWidget->setCurrentIndex(1);


        QMetaObject::connectSlotsByName(QtGuiAppCPPsucksClass);
    } // setupUi

    void retranslateUi(QMainWindow *QtGuiAppCPPsucksClass)
    {
        QtGuiAppCPPsucksClass->setWindowTitle(QApplication::translate("QtGuiAppCPPsucksClass", "QtGuiAppCPPsucks", Q_NULLPTR));
        OriginImage->setText(QApplication::translate("QtGuiAppCPPsucksClass", "origin image", Q_NULLPTR));
        pushButton->setText(QApplication::translate("QtGuiAppCPPsucksClass", "\346\211\223\345\274\200\345\233\276\345\203\217", Q_NULLPTR));
        pushButton_2->setText(QApplication::translate("QtGuiAppCPPsucksClass", "\347\201\260\345\272\246\345\214\226", Q_NULLPTR));
        pushButton_3->setText(QApplication::translate("QtGuiAppCPPsucksClass", "\347\274\251\346\224\276", Q_NULLPTR));
        pushButton_4->setText(QApplication::translate("QtGuiAppCPPsucksClass", "\346\214\211\346\257\224\344\276\213\347\274\251\346\224\276", Q_NULLPTR));
        pushButton_7->setText(QApplication::translate("QtGuiAppCPPsucksClass", "\351\253\230\346\226\257\346\250\241\347\263\212", Q_NULLPTR));
        pushButton_8->setText(QApplication::translate("QtGuiAppCPPsucksClass", "\351\224\220\345\214\226", Q_NULLPTR));
        pushButton_9->setText(QApplication::translate("QtGuiAppCPPsucksClass", "\350\275\256\345\273\223\346\243\200\346\265\213", Q_NULLPTR));
        label->setText(QApplication::translate("QtGuiAppCPPsucksClass", "\345\256\275\345\272\246:500.\351\253\230\345\272\246:500", Q_NULLPTR));
        label_2->setText(QApplication::translate("QtGuiAppCPPsucksClass", "\347\274\251\346\224\276\346\257\224\344\276\213\357\274\2320.5", Q_NULLPTR));
        tabWidget->setTabText(tabWidget->indexOf(TabPicture), QApplication::translate("QtGuiAppCPPsucksClass", "Picture", Q_NULLPTR));
        VideoOrigin->setText(QApplication::translate("QtGuiAppCPPsucksClass", "Origin Video", Q_NULLPTR));
        VideoOpenVideo->setText(QApplication::translate("QtGuiAppCPPsucksClass", "\346\211\223\345\274\200\350\247\206\351\242\221", Q_NULLPTR));
        VideoGraying->setText(QApplication::translate("QtGuiAppCPPsucksClass", "\347\201\260\345\272\246\345\214\226", Q_NULLPTR));
        pushButton_5->setText(QApplication::translate("QtGuiAppCPPsucksClass", "\345\205\263\351\227\255\350\247\206\351\242\221", Q_NULLPTR));
        label_6->setText(QApplication::translate("QtGuiAppCPPsucksClass", "\346\211\223\345\274\200\350\247\206\351\242\221\344\271\213\345\220\216\350\247\206\351\242\221\344\270\215\344\274\232\347\253\213\345\210\273\346\222\255\346\224\276\357\274\214\347\202\271\345\207\273\347\201\260\345\272\246\345\214\226\344\271\213\345\220\216", Q_NULLPTR));
        label_7->setText(QApplication::translate("QtGuiAppCPPsucksClass", "\345\216\237\350\247\206\351\242\221\345\222\214\347\201\260\345\272\246\345\214\226\344\271\213\345\220\216\347\232\204\345\220\214\346\255\245\346\222\255\346\224\276\357\274\214\346\222\255\346\224\276\345\256\214\345\220\216\345\217\257\344\273\245\345\205\263\346\216\211\345\274\271\345\207\272\347\232\204gray\347\252\227\345\217\243", Q_NULLPTR));
        label_8->setText(QApplication::translate("QtGuiAppCPPsucksClass", "\346\210\226\350\200\205\344\270\255\351\200\224\347\202\271\345\207\273\345\205\263\351\227\255\350\247\206\351\242\221\346\214\211\351\222\256\344\271\237\345\217\257\344\273\245\351\200\200\345\207\272", Q_NULLPTR));
        tabWidget->setTabText(tabWidget->indexOf(TabVideo), QApplication::translate("QtGuiAppCPPsucksClass", "Video", Q_NULLPTR));
        pushButton_10->setText(QApplication::translate("QtGuiAppCPPsucksClass", "\346\211\223\345\274\200\346\221\204\345\203\217\345\244\264", Q_NULLPTR));
        pushButton_11->setText(QApplication::translate("QtGuiAppCPPsucksClass", "\345\205\263\351\227\255\346\221\204\345\203\217\345\244\264", Q_NULLPTR));
        label_3->setText(QApplication::translate("QtGuiAppCPPsucksClass", "\346\211\223\345\274\200\346\221\204\345\203\217\345\244\264\344\274\232\350\277\233\350\241\214\350\275\256\345\273\223\346\243\200\346\265\213\357\274\214\346\234\254\346\235\245\346\211\223\347\256\227\345\201\232\347\211\251\344\275\223\350\257\206\345\210\253\347\232\204\357\274\214\344\275\206\346\230\257\346\227\266\351\227\264\346\234\211\351\231\220\357\274\214\345\260\261\345\201\232\344\272\206\344\270\200\344\270\252\350\275\256\345\273\223\346\243\200\346\265\213\343\200\202", Q_NULLPTR));
        label_4->setText(QApplication::translate("QtGuiAppCPPsucksClass", "\345\205\267\344\275\223\346\230\257\346\240\271\346\215\256\351\273\221\347\231\275\345\233\276\345\257\271\345\233\276\347\211\207\346\235\245\345\210\206\345\211\262\345\207\272\344\270\215\345\220\214\347\232\204\351\203\250\345\210\206\357\274\214\346\257\217\344\270\200\344\270\252\351\203\250\345\210\206\347\224\250\344\270\200\344\270\252\345\234\206\345\234\210\345\207\272\346\235\245", Q_NULLPTR));
        label_5->setText(QApplication::translate("QtGuiAppCPPsucksClass", "\351\200\232\350\277\207\345\205\263\351\227\255\346\221\204\345\203\217\345\244\264\346\214\211\351\222\256\346\235\245\345\205\263\351\227\255", Q_NULLPTR));
        tabWidget->setTabText(tabWidget->indexOf(TabCamera), QApplication::translate("QtGuiAppCPPsucksClass", "Camera", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class QtGuiAppCPPsucksClass: public Ui_QtGuiAppCPPsucksClass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_QTGUIAPPCPPSUCKS_H
