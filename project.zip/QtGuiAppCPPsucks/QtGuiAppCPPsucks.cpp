#include "QtGuiAppCPPsucks.h"

QtGuiAppCPPsucks::QtGuiAppCPPsucks(QWidget *parent)
	: QMainWindow(parent)
{
	ui.setupUi(this);
}

void QtGuiAppCPPsucks::PicOpenPicButtonClicked()
{
    QFileDialog* fileDialog = new QFileDialog(this);
    //�����ļ��Ի������
    fileDialog->setWindowTitle(tr("open image"));
    //����Ĭ���ļ�·��
    fileDialog->setDirectory(".");
    //�����ļ�������
    //fileDialog->setNameFilter(tr("Images(*.png *.jpg *.jpeg *.bmp)"));
    //���ÿ���ѡ�����ļ�,Ĭ��Ϊֻ��ѡ��һ���ļ�QFileDialog::ExistingFiles
    //fileDialog->setFileMode(QFileDialog::ExistingFiles);
    //������ͼģʽ
    fileDialog->setViewMode(QFileDialog::Detail);
    //��ӡ����ѡ����ļ���·��
    
    QStringList fileNames;
    QString filepath;
    if (fileDialog->exec())//��ȷ���ļ�ѡ����
    {
        fileNames = fileDialog->selectedFiles();
        if (fileNames.length() > 0) filepath = fileNames[0];
        else return;
    }
 
	QImage* img = new  QImage();
	
    if (!(img->load(filepath)))
    {
        QMessageBox::information(this,
            tr("open image failed!"),
            tr("open image failed!"));
         delete img;
         return;
    }
	OriginImagePath = filepath;
	(*img) = img->scaled((&ui)->OriginImage->width(), (&ui)->OriginImage->height());
	(&ui)->OriginImage->setPixmap(QPixmap::fromImage(*img));
}

Mat QImage2Mat(QImage* InputImage)
{
	Mat mat = Mat((*InputImage).height(), (*InputImage).width(),
		CV_8UC3, (void*)(*InputImage).constBits(), (*InputImage).bytesPerLine());
	return mat;
}
void Graying(Mat source)
{
	Mat dst;
	cvtColor(source, dst, COLOR_RGB2GRAY);
	cv::imshow("Graying", dst);
	cv::waitKey(0);
	return;
}

void QtGuiAppCPPsucks::GrayingButtonClicked()
{
	if (OriginImagePath.isEmpty())
	{
		QMessageBox::warning(this,
			tr("No Image!"),
			tr("please open image first!"));
		return;
	}
	Mat img = imread(OriginImagePath.toStdString());
	Graying(img);;
	return;
}


void Resize(Mat source, int width, int height)
{
	Mat dst;
	Size newsize = Size(width, height);
	resize(source, dst, newsize);
	cv::imshow("reszie", dst);
	cv::waitKey(0);
	return;
}

void QtGuiAppCPPsucks::ResizeButtonClicked()
{
	//String Width = (&ui)->WidthText.text();
	if (OriginImagePath.isEmpty())
	{
		QMessageBox::warning(this,
			tr("No Image!"),
			tr("please open image first!"));
		return;
	}
	Mat img = imread(OriginImagePath.toStdString());
	Resize(img,500,500);
	return;
}

void resizescale(Mat source, double scale)
{
	Mat dst;
	Size zero = Size(0, 0);
	resize(source, dst, zero, scale, scale);
	imshow("resize scale", dst);
	waitKey(0);
	return;
}
void QtGuiAppCPPsucks::ResizeScaleButtonClicked()
{
	if (OriginImagePath.isEmpty())
	{
		QMessageBox::warning(this,
			tr("No Image!"),
			tr("please open image first!"));
		return;
	}
	Mat img = imread(OriginImagePath.toStdString());
	resizescale(img, 0.5);
	return;
}


void CharConvert(Mat source)
{
	Mat gray;
	cvtColor(source, gray, COLOR_RGB2GRAY);
	//imshow("gray",gray);
	Size reduce = Size(120, 30);
	resize(gray, gray, reduce);
	//imshow("gray", gray);
	String strtable = "mqpka89045321@#$%^&*()_=||||}";
	int index;
	String charedpic;
	for (int i = 0; i < gray.rows; i++)
	{
		for (int j = 0; j < gray.cols; j++)
		{
			index = int((gray.at<uchar>(i, j) * 1.0 / 256) * strtable.length());
			charedpic = charedpic + strtable[index];
		}
	}
	std::cout << charedpic;

	return;
}

void QtGuiAppCPPsucks::CharConvertButtonClicked()
{

}

void Denoise(Mat source)
{//������Ϣ
	Mat dst;
	fastNlMeansDenoising(source, dst, 10, 5, 20);//this so called fastNlMeansDenoising really slow!!!
	imshow("denoise", dst);
	waitKey(0);
	return;
}
void QtGuiAppCPPsucks::DenoiseButtonClicked()
{
	if (OriginImagePath.isEmpty())
	{
		QMessageBox::warning(this,
			tr("No Image!"),
			tr("please open image first!"));
		return;
	}
	Mat img = imread(OriginImagePath.toStdString());
	Denoise(img);
	return;
}
void GuassBlur(Mat source)
{
	Mat dst;
	GaussianBlur(source, dst, Size(5, 5), 3, 3);
	imshow("GuassBlur", dst);
	waitKey(0);
	return;
}
void QtGuiAppCPPsucks::GuassBlurButtonClicked()
{
	if (OriginImagePath.isEmpty())
	{
		QMessageBox::warning(this,
			tr("No Image!"),
			tr("please open image first!"));
		return;
	}
	Mat img = imread(OriginImagePath.toStdString());
	GuassBlur(img);
	return;
}
//������˹��

void laplaceSharpenFliter2d(Mat source)
{
	Mat dst;
	Mat kernel = (Mat_<char>(3, 3) << 0, -1, 0, -1, 5, -1, 0, -1, 0);
	filter2D(source, dst, CV_32F, kernel);
	convertScaleAbs(dst, dst);
	imshow("filter2dlaplacesharpen ", dst);
	waitKey(0);
	return;
}

void QtGuiAppCPPsucks::SharpenButtonClicked()
{
	if (OriginImagePath.isEmpty())
	{
		QMessageBox::warning(this,
			tr("No Image!"),
			tr("please open image first!"));
		return;
	}
	Mat img = imread(OriginImagePath.toStdString());
	laplaceSharpenFliter2d(img);
	return;
}
void ContourRec(Mat source)
{
	//VideoCapture video = VideoCapture("C:\\Users\\10938\\Videos\\Captures\\jljt.mp4");
	//VideoCapture video = VideoCapture(0);
	Mat grey;
	cvtColor(source, grey, COLOR_RGB2GRAY);
	//imshow("grey", grey);
	Mat DoubleValue;
	threshold(grey, DoubleValue, 127, 255, THRESH_BINARY);
	imshow("doublevalued", DoubleValue);
	vector<vector<Point> >contours;
	vector<Vec4i> hireachy;
	findContours(DoubleValue, contours, hireachy, RETR_EXTERNAL, CHAIN_APPROX_SIMPLE, Point());
	//findContours(DoubleValue, contours, hireachy, RETR_TREE, CHAIN_APPROX_SIMPLE, Point());
	vector<Point2f>center(contours.size());
	vector<float>radius(contours.size());
	for (int i = 0; i < contours.size(); i++)
	{
		minEnclosingCircle(contours[i], center[i], radius[i]);
	}
	for (int i = 0; i < contours.size(); i++)
	{
		circle(source, Point(center[i]), radius[i], CV_RGB(0, 255, 0), 2);
	}
	imshow("circle", source);
	return;

}
void QtGuiAppCPPsucks::ContourRecButtonClicked()
{
	if (OriginImagePath.isEmpty())
	{
		QMessageBox::warning(this,
			tr("No Image!"),
			tr("please open image first!"));
		return;
	}
	Mat img = imread(OriginImagePath.toStdString());
	ContourRec(img);
	return;
}
void videoCharConv()///////////////
{
	VideoCapture video = VideoCapture("C:\\Users\\10938\\Videos\\Captures\\jljt.mp4");
	//VideoCapture video = VideoCapture(0);
	Mat frame;
	while (1)
	{
		video >> frame;

		if (frame.empty()) break;
		CharConvert(frame);
		//imshow("camera",frame);
		waitKey(10);
	}
	return;
}

void videoContourRec(VideoCapture camera)//����ʶ��
{
	//VideoCapture video = VideoCapture("C:\\Users\\10938\\Videos\\Captures\\jljt.mp4");
	//Camera = VideoCapture(0);
	
	//video.release()���Թر�
	Mat frame;
	while (1)
	{
		camera >> frame;
	//	if (this->videostop) break;
		if (frame.empty()) break;
		ContourRec(frame);
		//imshow("camera",frame);
		waitKey(10);
	}
	camera.release();
	return;
}

void QtGuiAppCPPsucks::CameraOpenClicked()
{
	
	VideoCapture Camera = VideoCapture(0);
	Mat frame;
	namedWindow("doublevalued");
	namedWindow("circle");
	while (1)
	{
		Camera >> frame;
		if (this ->videostop) break;
		if (frame.empty()) break;

		//ContourRec(frame);
		//imshow("camera",frame);
		Mat grey;
		cvtColor(frame, grey, COLOR_RGB2GRAY);
		//imshow("grey", grey);
		Mat DoubleValue;
		threshold(grey, DoubleValue, 75, 255, THRESH_BINARY);
		imshow("doublevalued", DoubleValue);
		vector<vector<Point> >contours;
		vector<Vec4i> hireachy;
		findContours(DoubleValue, contours, hireachy, RETR_EXTERNAL, CHAIN_APPROX_SIMPLE, Point());
		//findContours(DoubleValue, contours, hireachy, RETR_TREE, CHAIN_APPROX_SIMPLE, Point());
		vector<Point2f>center(contours.size());
		vector<float>radius(contours.size());
		for (int i = 0; i < contours.size(); i++)
		{
			minEnclosingCircle(contours[i], center[i], radius[i]);
		}
		for (int i = 0; i < contours.size(); i++)
		{
			circle(frame, Point(center[i]), radius[i], CV_RGB(0, 255, 0), 2);
		}
		imshow("circle", frame);
		waitKey(5);
	}
	Camera.release();
	destroyWindow("doublevalued");
	destroyWindow("circle");
	this->videostop = 0;
	return;
}

void QtGuiAppCPPsucks::CameraCloseClicked()
{
	this ->videostop = 1;
}

void QtGuiAppCPPsucks::OpenVideo()
{
	QFileDialog* fileDialog = new QFileDialog(this);
	//�����ļ��Ի������
	fileDialog->setWindowTitle(tr("open image"));
	//����Ĭ���ļ�·��
	fileDialog->setDirectory(".");
	//�����ļ�������
	//fileDialog->setNameFilter(tr("Images(*.png *.jpg *.jpeg *.bmp)"));
	//���ÿ���ѡ�����ļ�,Ĭ��Ϊֻ��ѡ��һ���ļ�QFileDialog::ExistingFiles
	//fileDialog->setFileMode(QFileDialog::ExistingFiles);
	//������ͼģʽ
	fileDialog->setViewMode(QFileDialog::Detail);
	//��ӡ����ѡ����ļ���·��

	QStringList fileNames;
	QString filepath;
	if (fileDialog->exec())//��ȷ���ļ�ѡ����
	{
		fileNames = fileDialog->selectedFiles();
		if (fileNames.length() > 0) filepath = fileNames[0];
		else return;
	}
	if (filepath.isEmpty())
	{
		QMessageBox::information(this,
			tr("No Video"),
			tr("open Video failed!"));
		//delete (&firstframe);
		return;
	}
	OriginVideoPath = filepath;
	VideoCapture video = VideoCapture(filepath.toStdString());
	Mat firstframe;
	video >> firstframe;

	cvtColor(firstframe,firstframe,COLOR_BGR2RGB);
	QImage firsrtFrame = QImage((const unsigned char*)firstframe.data, firstframe.cols, firstframe.rows, firstframe.step, QImage::Format_RGB888);
	(firsrtFrame) = (&firsrtFrame)->scaled((&ui)->VideoOrigin->width(), (&ui)->VideoOrigin->height());
	(&ui)->VideoOrigin->setPixmap(QPixmap::fromImage(firsrtFrame));
}

void QtGuiAppCPPsucks::VideoGraying()
{
	PlayStop = 0;
	if (OriginVideoPath.isEmpty())
	{
		QMessageBox::warning(this,
			tr("No Video"),
			tr("please open Video first!"));
		return;
	}
	VideoCapture VideoOrigin = VideoCapture(OriginVideoPath.toStdString());
	Mat frame;
	Mat gray;
	namedWindow("gray");
	while (1)
	{
		VideoOrigin >> frame;
		if (PlayStop) break;
		if (frame.empty()) break;
		cvtColor(frame, gray, COLOR_RGB2GRAY);
		imshow("gray", gray);
		waitKey(2);
		cvtColor(frame, frame, COLOR_BGR2RGB);
		QImage Frame = QImage((const unsigned char*)frame.data, frame.cols, frame.rows, frame.step, QImage::Format_RGB888);
		(Frame) = (&Frame)->scaled((&ui)->VideoOrigin->width(), (&ui)->VideoOrigin->height());
		(&ui)->VideoOrigin->setPixmap(QPixmap::fromImage(Frame));
		waitKey(2);
	}
	destroyWindow("gray");
	VideoOrigin.release();
	PlayStop = 0;
	return;
}

void QtGuiAppCPPsucks::CloseVideo()
{
	PlayStop = 1;
}